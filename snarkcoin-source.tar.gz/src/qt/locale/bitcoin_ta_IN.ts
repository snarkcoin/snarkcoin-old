<TS language="ta_IN" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Create a new address</source>
        <translation>புதிய முகவரியை உருவாக்கவும்</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>பட்டியலிலிருந்து தற்போது தேர்ந்தெடுக்கப்பட்ட முகவரி நீக்கவும்</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>கடவுச்சொல் உரையாடல் </translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>புதிய கடவுச்சொல்</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>குறியாக்க பணப்பையை</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>பணப்பை திறக்க</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>பணப்பை குறியாக்க</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>கடுவு சொற்றொடரை மாற்று</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Error</source>
        <translation>பிழை</translation>
    </message>
    </context>
<context>
    <name>CoinControlDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    </context>
<context>
    <name>Intro</name>
    <message>
        <source>Error</source>
        <translation>பிழை</translation>
    </message>
    </context>
<context>
    <name>ModalOverlay</name>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Error</source>
        <translation>பிழை</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    </context>
<context>
    <name>PaymentServer</name>
    <message>
        <source>Payment acknowledged</source>
        <translation>கட்டணம் ஒப்புக் கொண்டது</translation>
    </message>
</context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>unknown</source>
        <translation>தெரியாத</translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>Requested payments history</source>
        <translation>பணம் செலுத்திய வரலாறு கோரப்பட்டது</translation>
    </message>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Payment information</source>
        <translation>கொடுப்பனவு தகவல்</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Balance:</source>
        <translation>இருப்பு:</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>SendConfirmationDialog</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>unknown</source>
        <translation>தெரியாத</translation>
    </message>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Today</source>
        <translation>இன்று</translation>
    </message>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletController</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Insufficient funds</source>
        <translation>போதுமான பணம் இல்லை</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>பிழை</translation>
    </message>
</context>
</TS>